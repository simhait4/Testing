﻿using System;

namespace ConsoleApp4
{
    class Program
    {
        static void Main(string[] args)
        {
            PrintFIZZBUZZ();
            string input = Console.ReadLine();
            string reveredString = reverseString(input);
            Console.WriteLine("Reverse String : " + reveredString);
            Console.ReadLine();

            //---------------------------------------------- SQL Queries
            //Select * from orders join customer on orders.cusotmerid = customers.cusotmerid 
            //join prderproducts on orders.orderid = orderproduct.orderid
            //join products on orderproducts.productid = products.productid
            //where  customer.name like 'joe%'


            //Select * from orders join customer on orders.cusotmerid = customers.cusotmerid 
            //join prderproducts on orders.orderid = orderproduct.orderid
            //join products on orderproducts.productid = products.productid
            //where  Orders.orderdate >'11/1/2016'

            //Select customers.customername, SUM(products.price * orderproducts.quantity) as totalAmountSpent from orders join customer on orders.cusotmerid = customers.cusotmerid 
            //join prderproducts on orders.orderid = orderproduct.orderid
            //join products on orderproducts.productid = products.productid
            //where  customers.customername='Joe'
            //grougp by cusotmers.customername



            //Select customers.customername, COUNT(distinct orders.orderid) as ordercount from customers join orders on customers.cusotmerid =orders.cusotmerid 
            //join prderproducts on orders.orderid = orderproduct.orderid
            //group by customers.customername
            //having Count(distinct orderproducts.productid)>1

            //----------------------------------------------


        }


        static void PrintFIZZBUZZ()
        {
            for(int i=0; i<=100; i++)
            {
                if (i % 3 == 0)
                    Console.WriteLine("fizz");
                else if(i % 5 == 0 )
                    Console.WriteLine("buzz");
                else if(i % 3 == 0 && i %5 ==0)
                    Console.WriteLine("fizzbuzz");
            }
        }

        static string reverseString(string input)
        {
            char[] charArry = input.ToCharArray();
            Array.Reverse(charArry);
            return new string(charArry);
        }

    }
}
