﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebApplication1.Models
{
    public class OfferService
    {
        private List<Product> Inventory { get; set; }
        private OfferService()
        {
            Inventory =  new List<Product> { new Product { ProductName = "P1", Price = 1000, Description = "P1 Desc" },
                                             new Product { ProductName = "P2", Price = 0, Description = "P2 Desc" },
                                             new Product { ProductName = "P3", Price = 0, Description = "P3 Desc" },
                                             new Product { ProductName = "P4", Price = 0, Description = "P4 Desc" },
                                             new Product { ProductName = "P5", Price = 0, Description = "P5 Desc" },
                                             new Product { ProductName = "P6", Price = 0, Description = "P6 Desc" }};
        }

        public List<Product> GetAllProducts()
        {
            return this.Inventory;
        }

        public List<Product> GetTodaysOffers()
        {
            var products = new List<Product> { new Product {ProductName = "P7Combo", Price = 1000, Description = "P7 Combo Desc"  },
                                                         new Product {ProductName = "P8Combo", Price = 1000, Description = "P8 Combo Desc"  },
                                                         new Product {ProductName = "P9Combo", Price = 1000, Description = "P9 Combo Desc"  }};
            return products;
        }
    }
}
